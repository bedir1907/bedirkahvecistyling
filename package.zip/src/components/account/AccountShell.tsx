import Link from "next/link"
import { ChevronRight, LayoutGrid, MapPin, Package, Settings } from "lucide-react"

type AccountShellProps = {
  current: "account" | "orders" | "addresses" | "settings"
  children: React.ReactNode
}

const navItems = [
  {
    key: "account",
    href: "/hesabim",
    label: "Genel Bakış",
    icon: LayoutGrid,
  },
  {
    key: "orders",
    href: "/siparislerim",
    label: "Siparişlerim",
    icon: Package,
  },
  {
    key: "addresses",
    href: "/hesabim/adreslerim",
    label: "Adreslerim",
    icon: MapPin,
  },
  {
    key: "settings",
    href: "/hesabim/ayarlar",
    label: "Ayarlar",
    icon: Settings,
  },
] as const

export default function AccountShell({
  current,
  children,
}: AccountShellProps) {
  return (
    <main className="min-h-screen bg-white text-[#111]">
      <section className="max-w-6xl mx-auto px-4 py-10">
        <div className="grid lg:grid-cols-[240px_1fr] gap-10">
          
          {/* Sidebar */}
          <aside className="space-y-2">
            {navItems.map((item) => {
              const Icon = item.icon
              const isActive = item.key === current

              return (
                <Link
                  key={item.key}
                  href={item.href}
                  className={`flex items-center justify-between px-3 py-3 text-sm transition ${
                    isActive
                      ? "text-black font-medium"
                      : "text-gray-400 hover:text-black"
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon size={16} />
                    <span>{item.label}</span>
                  </div>

                  <ChevronRight size={14} />
                </Link>
              )
            })}
          </aside>

          {/* Content */}
          <div className="space-y-8">{children}</div>
        </div>
      </section>
    </main>
  )
}