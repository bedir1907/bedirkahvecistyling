"use client"

import { useMemo, useState } from "react"
import { useRouter } from "next/navigation"
import AnnouncementBar from "@/components/store/AnnouncementBar"
import StoreNavbar from "@/components/store/StoreNavbar"
import StoreFooter from "@/components/store/StoreFooter"
import { useCartStore } from "@/store/cartStore"

export default function CheckoutPage() {
  const router = useRouter()

  const cart = useCartStore((state) => state.cart)
  const clearCart = useCartStore((state) => state.clearCart)

  const [form, setForm] = useState({
    name: "",
    email: "",
    phone: "",
    city: "",
    district: "",
    address: "",
    note: "",
  })

  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")

  const total = useMemo(() => {
    return cart.reduce((sum, item) => sum + item.price * item.quantity, 0)
  }, [cart])

  function handleChange(
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) {
    const { name, value } = e.target

    setForm((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault()
    setError("")

    if (cart.length === 0) {
      setError("Sepet boş")
      return
    }

    if (
      !form.name.trim() ||
      !form.email.trim() ||
      !form.phone.trim() ||
      !form.city.trim() ||
      !form.district.trim() ||
      !form.address.trim()
    ) {
      setError("Lütfen zorunlu alanları doldur")
      return
    }

    setLoading(true)

    try {
      const res = await fetch("/api/payment/iyzico/initialize", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...form,
          cart,
        }),
      })

      const data = await res.json()

      if (!res.ok) {
        throw new Error(data.error || "Ödeme başlatılamadı")
      }

      if (!data.paymentPageUrl) {
        throw new Error("Ödeme sayfası oluşturulamadı")
      }
      localStorage.setItem("pendingOrderNumber", data.orderNumber)
      window.location.href = data.paymentPageUrl
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Ödeme başlatılırken hata oluştu"
      )
    } finally {
      setLoading(false)
    }
  }

  if (cart.length === 0) {
    return (
      <main className="min-h-screen bg-white text-black">
        <AnnouncementBar />
        <StoreNavbar />

        <section className="max-w-3xl mx-auto px-4 py-20 text-center">
          <h1 className="text-3xl font-semibold tracking-tight">Sepet Boş</h1>
          <p className="text-gray-600 mt-3">
            Checkout sayfasına devam etmek için önce sepete ürün eklemelisin.
          </p>

          <button
            type="button"
            onClick={() => router.push("/")}
            className="mt-8 px-6 py-3 rounded-2xl bg-black text-white hover:opacity-90 transition"
          >
            Alışverişe Dön
          </button>
        </section>

        <StoreFooter />
      </main>
    )
  }

  return (
    <main className="min-h-screen bg-white text-black">
      <AnnouncementBar />
      <StoreNavbar />

      <section className="max-w-7xl mx-auto px-4 py-10 md:py-14">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-semibold tracking-tight">
            Checkout
          </h1>
          <p className="text-gray-600 mt-2">
            Teslimat bilgilerini girip ödemenize geçebilirsiniz.
          </p>
        </div>

        <div className="grid lg:grid-cols-[1fr_420px] gap-10 items-start">
          <form
            onSubmit={handleSubmit}
            className="bg-white border rounded-3xl p-6 md:p-8 space-y-5"
          >
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Ad Soyad
                </label>
                <input
                  type="text"
                  name="name"
                  value={form.name}
                  onChange={handleChange}
                  className="w-full border rounded-2xl px-4 py-3"
                  placeholder="Ad Soyad"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  E-posta
                </label>
                <input
                  type="email"
                  name="email"
                  value={form.email}
                  onChange={handleChange}
                  className="w-full border rounded-2xl px-4 py-3"
                  placeholder="mail@ornek.com"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Telefon
                </label>
                <input
                  type="text"
                  name="phone"
                  value={form.phone}
                  onChange={handleChange}
                  className="w-full border rounded-2xl px-4 py-3"
                  placeholder="05xx xxx xx xx"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Şehir</label>
                <input
                  type="text"
                  name="city"
                  value={form.city}
                  onChange={handleChange}
                  className="w-full border rounded-2xl px-4 py-3"
                  placeholder="Şehir"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium mb-2">İlçe</label>
                <input
                  type="text"
                  name="district"
                  value={form.district}
                  onChange={handleChange}
                  className="w-full border rounded-2xl px-4 py-3"
                  placeholder="İlçe"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium mb-2">Adres</label>
                <textarea
                  name="address"
                  value={form.address}
                  onChange={handleChange}
                  className="w-full border rounded-2xl px-4 py-3 min-h-[120px]"
                  placeholder="Mahalle, sokak, bina no, daire no..."
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium mb-2">
                  Sipariş Notu
                </label>
                <textarea
                  name="note"
                  value={form.note}
                  onChange={handleChange}
                  className="w-full border rounded-2xl px-4 py-3 min-h-[100px]"
                  placeholder="Varsa sipariş notunuzu yazın"
                />
              </div>
            </div>

            {error ? (
              <div className="rounded-2xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                {error}
              </div>
            ) : null}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-2xl bg-black text-white px-6 py-4 text-base font-medium hover:opacity-90 transition disabled:opacity-50"
            >
              {loading ? "Ödeme Başlatılıyor..." : "Ödemeye Geç"}
            </button>
          </form>

          <aside className="bg-white border rounded-3xl p-6 md:p-8 lg:sticky lg:top-24">
            <h2 className="text-2xl font-semibold tracking-tight mb-6">
              Sipariş Özeti
            </h2>

            <div className="space-y-4">
              {cart.map((item, index) => (
                <div
                  key={`${item.variantId}-${index}`}
                  className="flex items-start justify-between gap-4 border-b pb-4"
                >
                  <div>
                    <div className="font-medium leading-snug">{item.name}</div>

                    <div className="text-sm text-gray-500 mt-1">
                      {item.color ? `Renk: ${item.color}` : null}
                      {item.color && item.size ? " • " : null}
                      {item.size ? `Beden: ${item.size}` : null}
                    </div>

                    <div className="text-sm text-gray-500 mt-1">
                      {item.quantity} adet × ₺{item.price}
                    </div>
                  </div>

                  <div className="font-medium whitespace-nowrap">
                    ₺{item.price * item.quantity}
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-6 space-y-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-gray-500">Ara Toplam</span>
                <span>₺{total}</span>
              </div>

              <div className="flex items-center justify-between">
                <span className="text-gray-500">Kargo</span>
                <span>Ücretsiz</span>
              </div>

              <div className="flex items-center justify-between text-base font-semibold border-t pt-4">
                <span>Toplam</span>
                <span>₺{total}</span>
              </div>
            </div>
          </aside>
        </div>
      </section>

      <StoreFooter />
    </main>
  )
}