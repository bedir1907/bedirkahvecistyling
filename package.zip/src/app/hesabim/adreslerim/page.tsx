import Link from "next/link"
import { redirect } from "next/navigation"
import { Home, MapPin, Plus, ChevronRight } from "lucide-react"
import { getCustomerUserFromCookie } from "@/lib/customer-auth"
import AccountShell from "@/components/account/AccountShell"

export default async function AddressesPage() {
  const customer = await getCustomerUserFromCookie()

  if (!customer) {
    redirect("/giris")
  }

  return (
    <AccountShell current="addresses">
      <div className="max-w-2xl pb-2">
        <p className="text-xs uppercase tracking-[0.18em] text-gray-400 mb-3">
          Adresler
        </p>
        <h2 className="text-2xl md:text-3xl font-medium tracking-tight text-black">
          Teslimat ve fatura bilgileri
        </h2>
        <p className="text-sm text-gray-400 mt-3">
          Kayıtlı adreslerini bu alandan yöneteceksin.
        </p>
      </div>

      <div className="rounded-3xl border border-black/10 bg-[#fcfcfb] p-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-8">
          <div>
            <div className="text-xs uppercase tracking-[0.18em] text-gray-400 mb-3">
              Kayıtlı Adresler
            </div>
            <div className="text-2xl font-medium">Henüz adres yok</div>
            <p className="text-sm text-gray-500 mt-2">
              Teslimat ve fatura adreslerini eklediğinde burada listelenecek.
            </p>
          </div>

          <button
            type="button"
            disabled
            className="inline-flex items-center justify-center gap-2 rounded-2xl border border-black/10 bg-white px-5 py-3 text-sm font-medium opacity-60 cursor-not-allowed"
          >
            <Plus size={16} />
            Yeni Adres Ekle
          </button>
        </div>

        <div className="rounded-3xl border border-dashed border-black/10 bg-white px-6 py-12 text-center">
          <div className="w-16 h-16 rounded-full border border-black/10 mx-auto flex items-center justify-center mb-5">
            <MapPin size={24} className="text-gray-500" />
          </div>

          <h3 className="text-2xl font-medium">Adres bulunamadı</h3>

          <p className="text-gray-500 mt-3 max-w-2xl mx-auto leading-7">
            Bu alanı sade bırakıyoruz. Bir sonraki adımda adres ekleme,
            varsayılan adres seçimi ve checkout’ta otomatik doldurma
            özelliklerini bağlayacağız.
          </p>

          <div className="mt-6">
            <Link
              href="/"
              className="inline-flex items-center justify-center gap-2 rounded-2xl border border-black/10 bg-white px-5 py-3 text-sm font-medium hover:bg-[#fafaf8] transition"
            >
              <Home size={16} />
              Alışverişe Dön
            </Link>
          </div>
        </div>
      </div>

      <div className="rounded-3xl border border-black/10 bg-[#fcfcfb] p-6">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs uppercase tracking-[0.18em] text-gray-400 mb-3">
              Sonraki Adım
            </div>
            <div className="text-xl font-medium">Adres yönetimi hazırlanıyor</div>
            <p className="text-sm text-gray-500 mt-2">
              Adres ekleme, düzenleme ve varsayılan adres seçimi burada yer alacak.
            </p>
          </div>

          <div className="hidden md:flex items-center gap-2 text-sm text-gray-400">
            <span>Yakında</span>
            <ChevronRight size={16} />
          </div>
        </div>
      </div>
    </AccountShell>
  )
}