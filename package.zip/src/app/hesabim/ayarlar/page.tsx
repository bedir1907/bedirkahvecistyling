import { redirect } from "next/navigation"
import { Save, ShieldCheck, User2 } from "lucide-react"
import { getCustomerUserFromCookie } from "@/lib/customer-auth"
import AccountShell from "@/components/account/AccountShell"

export default async function SettingsPage() {
  const customer = await getCustomerUserFromCookie()

  if (!customer) {
    redirect("/giris")
  }

  return (
    <AccountShell current="settings">
      <div className="max-w-2xl pb-2">
        <p className="text-xs uppercase tracking-[0.18em] text-gray-400 mb-3">
          Hesap
        </p>
        <h2 className="text-2xl md:text-3xl font-medium tracking-tight text-black">
          Profil ve hesap ayarları
        </h2>
        <p className="text-sm text-gray-400 mt-3">
          Temel müşteri bilgilerini bu alandan düzenleyeceksin.
        </p>
      </div>

      <div className="rounded-3xl border border-black/10 bg-[#fcfcfb] p-8">
        <div className="flex items-center gap-3 mb-8">
          <div className="w-12 h-12 rounded-full border border-black/10 bg-white flex items-center justify-center">
            <User2 size={20} />
          </div>
          <div>
            <h3 className="text-2xl font-medium">Profil Bilgileri</h3>
            <p className="text-sm text-gray-500 mt-1">
              Müşteri profil bilgilerini düzenleme alanı
            </p>
          </div>
        </div>

        <form className="grid md:grid-cols-2 gap-5">
          <div>
            <label className="text-xs uppercase tracking-[0.18em] text-gray-400 block mb-3">
              Ad Soyad
            </label>
            <input
              type="text"
              defaultValue={customer.name}
              className="w-full rounded-2xl border border-black/10 bg-white px-4 py-3 outline-none focus:border-black"
            />
          </div>

          <div>
            <label className="text-xs uppercase tracking-[0.18em] text-gray-400 block mb-3">
              Telefon
            </label>
            <input
              type="text"
              defaultValue={customer.phone || ""}
              className="w-full rounded-2xl border border-black/10 bg-white px-4 py-3 outline-none focus:border-black"
              placeholder="05xx xxx xx xx"
            />
          </div>

          <div className="md:col-span-2">
            <label className="text-xs uppercase tracking-[0.18em] text-gray-400 block mb-3">
              E-posta
            </label>
            <input
              type="email"
              defaultValue={customer.email}
              className="w-full rounded-2xl border border-black/10 bg-white px-4 py-3 outline-none focus:border-black"
            />
          </div>

          <div className="md:col-span-2 rounded-3xl border border-black/10 bg-white px-4 py-4 flex items-start justify-between gap-4">
            <div className="flex items-start gap-3">
              <ShieldCheck size={18} className="mt-0.5" />
              <div>
                <div className="font-medium">Hesap güvenliği</div>
                <div className="text-sm text-gray-500 mt-1">
                  Şifre değiştirme ve güvenlik ayarları bir sonraki aşamada bağlanacak.
                </div>
              </div>
            </div>

            <button
              type="button"
              disabled
              className="rounded-2xl border border-black/10 px-4 py-2 text-sm font-medium opacity-60 cursor-not-allowed"
            >
              Yakında
            </button>
          </div>

          <div className="md:col-span-2 pt-2">
            <button
              type="button"
              disabled
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-[#1C1C1E] text-white px-5 py-3 text-sm font-medium opacity-60 cursor-not-allowed"
            >
              <Save size={16} />
              Kaydet
            </button>
          </div>
        </form>
      </div>
    </AccountShell>
  )
}