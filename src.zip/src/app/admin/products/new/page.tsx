"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"

type Category = {
  id: number
  name: string
  slug: string
}

export default function NewProductPage() {
  const router = useRouter()

  const [categories, setCategories] = useState<Category[]>([])
  const [loading, setLoading] = useState(false)

  const [form, setForm] = useState({
    name: "",
    slug: "",
    price: "",
    oldPrice: "",
    image: "",
    category: "",
    description: "",
    sizes: "",
    colors: "",
    stock: "",
    featured: false,
    isNew: false,
    isActive: true,
    displayOrder: "0",
  })

  useEffect(() => {
    async function fetchCategories() {
      try {
        const res = await fetch("/api/admin/categories/list")
        const data = await res.json()
        setCategories(data)

        if (data.length > 0) {
          setForm((prev) => ({
            ...prev,
            category: data[0].name,
          }))
        }
      } catch (error) {
        console.error(error)
      }
    }

    fetchCategories()
  }, [])

  function handleChange(
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) {
    const { name, value, type } = e.target

    if (type === "checkbox") {
      const checked = (e.target as HTMLInputElement).checked
      setForm((prev) => ({ ...prev, [name]: checked }))
      return
    }

    setForm((prev) => ({ ...prev, [name]: value }))
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setLoading(true)

    try {
      const res = await fetch("/api/admin/products", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...form,
          sizes: form.sizes.split(",").map((item) => item.trim()).filter(Boolean),
          colors: form.colors.split(",").map((item) => item.trim()).filter(Boolean),
        }),
      })

      if (!res.ok) {
        const data = await res.json()
        throw new Error(data.error || "Ürün eklenemedi")
      }

      router.push("/admin/products")
      router.refresh()
    } catch (error) {
      alert(error instanceof Error ? error.message : "Ürün eklenemedi")
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="min-h-screen bg-gray-100">
      <div className="max-w-3xl mx-auto py-10">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold">Yeni Ürün Ekle</h1>
            <p className="text-gray-600 mt-1">Yeni ürün bilgilerini gir</p>
          </div>

          <Link
            href="/admin/products"
            className="border border-black px-4 py-2 rounded hover:bg-black hover:text-white"
          >
            Geri Dön
          </Link>
        </div>

        <form
          onSubmit={handleSubmit}
          className="bg-white rounded-xl shadow p-6 space-y-5"
        >
          <div>
            <label className="block mb-2 font-medium">Ürün Adı</label>
            <input
              name="name"
              value={form.name}
              onChange={handleChange}
              className="w-full border rounded px-4 py-3"
              required
            />
          </div>

          <div>
            <label className="block mb-2 font-medium">Slug</label>
            <input
              name="slug"
              value={form.slug}
              onChange={handleChange}
              className="w-full border rounded px-4 py-3"
              required
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block mb-2 font-medium">Fiyat</label>
              <input
                name="price"
                value={form.price}
                onChange={handleChange}
                type="number"
                className="w-full border rounded px-4 py-3"
                required
              />
            </div>

            <div>
              <label className="block mb-2 font-medium">Eski Fiyat</label>
              <input
                name="oldPrice"
                value={form.oldPrice}
                onChange={handleChange}
                type="number"
                className="w-full border rounded px-4 py-3"
              />
            </div>
          </div>

          <div>
            <label className="block mb-2 font-medium">Görsel URL</label>
            <input
              name="image"
              value={form.image}
              onChange={handleChange}
              className="w-full border rounded px-4 py-3"
              required
            />
          </div>

          <div>
            <label className="block mb-2 font-medium">Kategori</label>
            <select
              name="category"
              value={form.category}
              onChange={handleChange}
              className="w-full border rounded px-4 py-3"
              required
            >
              {categories.map((category) => (
                <option key={category.id} value={category.name}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block mb-2 font-medium">Açıklama</label>
            <textarea
              name="description"
              value={form.description}
              onChange={handleChange}
              className="w-full border rounded px-4 py-3 min-h-[120px]"
              required
            />
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block mb-2 font-medium">Bedenler (virgülle)</label>
              <input
                name="sizes"
                value={form.sizes}
                onChange={handleChange}
                className="w-full border rounded px-4 py-3"
                placeholder="S, M, L, XL"
                required
              />
            </div>

            <div>
              <label className="block mb-2 font-medium">Renkler (virgülle)</label>
              <input
                name="colors"
                value={form.colors}
                onChange={handleChange}
                className="w-full border rounded px-4 py-3"
                placeholder="Siyah, Beyaz"
                required
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block mb-2 font-medium">Stok</label>
              <input
                name="stock"
                value={form.stock}
                onChange={handleChange}
                type="number"
                className="w-full border rounded px-4 py-3"
                required
              />
            </div>

            <div>
              <label className="block mb-2 font-medium">Vitrin Sırası</label>
              <input
                name="displayOrder"
                value={form.displayOrder}
                onChange={handleChange}
                type="number"
                className="w-full border rounded px-4 py-3"
              />
            </div>
          </div>

          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              name="featured"
              checked={form.featured}
              onChange={handleChange}
            />
            <span>Öne çıkan ürün</span>
          </label>

          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              name="isNew"
              checked={form.isNew}
              onChange={handleChange}
            />
            <span>Yeni gelen ürün</span>
          </label>

          <label className="flex items-center gap-3">
            <input
              type="checkbox"
              name="isActive"
              checked={form.isActive}
              onChange={handleChange}
            />
            <span>Aktif ürün</span>
          </label>

          <button
            type="submit"
            disabled={loading}
            className="bg-black text-white px-6 py-3 rounded hover:opacity-90 disabled:opacity-50"
          >
            {loading ? "Kaydediliyor..." : "Ürünü Kaydet"}
          </button>
        </form>
      </div>
    </main>
  )
}